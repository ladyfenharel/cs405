Process Summary

IDE I used: Visual Studio Code with the Developer Command Prompt for Visual Studio 2022.

Steps to Build and Run in VS Code

Unzip the project folder. It should contain:

Encryption.cpp

inputdatafile.txt

Open the folder in VS Code (File → Open Folder).

Open a terminal inside VS Code (Ctrl+` ).

Make sure you launched VS Code from the Developer Command Prompt for VS 2022 so the compiler (cl.exe) is available.

In the terminal, build the program with:

cl /EHsc /std:c++17 Encryption.cpp


This creates Encryption.exe in the same folder.

Run the program with:

Encryption.exe
// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <stdexcept>  // Added for standard exception types
#include <exception>  // Added for base std::exception class

/**
 * Custom exception class for best practices:
 * 1. Derives from std::exception to maintain standard hierarchy
 * 2. Overrides what() method with noexcept specification for safety
 * 3. Uses descriptive naming convention with clear purpose
 */
class CustomApplicationException : public std::exception
{
public:
    const char* what() const noexcept override
    {
        return "Custom Application Exception occurred in application logic";
    }
};

bool do_even_more_custom_application_logic()
{
    // TODO: Throw any standard exception (COMPLETED)
    std::cout << "Running Even More Custom Application Logic." << std::endl;
    
    // Throwing standard runtime_error exception for standard exception handling
    throw std::runtime_error("Simulated error: Business logic validation failed");
    
    return true; // Line won't be reached due to exception
}

void do_custom_application_logic()
{
    // TODO: Wrap the call to do_even_more_custom_application_logic() (COMPLETED)
    // with an exception handler that catches std::exception, displays
    // a message and the exception.what(), then continues processing
    std::cout << "Running Custom Application Logic." << std::endl;

    try
    {
        // Try to execute nested logic that may throw standard exceptions
        if(do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch(const std::exception& e)
    {
        // Using std::exception base class to catch any standard library exception
        std::cout << "Caught standard exception in custom application logic: " << e.what() << std::endl;
        std::cout << "Continuing processing after handling exception..." << std::endl;
    }

    // TODO: Throw a custom exception derived from std::exception (COMPLETED)
    // and catch it explicitly in main
    std::cout << "About to throw custom exception..." << std::endl;
    throw CustomApplicationException();

    // Line will never be reached due to exception
    std::cout << "Leaving Custom Application Logic." << std::endl;
}

float divide(float num, float den)
{
    // TODO: Throw an exception to deal with divide by zero errors using (COMPLETED)
    // a standard C++ defined exception
    if (den == 0.0f)
    {
        throw std::invalid_argument("Division by zero error");
    }
    return (num / den);
}

void do_division() noexcept
{
    // TODO: create an exception handler to capture ONLY the exception thrown by divide. (COMPLETED)
    try
    {
        float numerator = 10.0f;
        float denominator = 0; // Intentionally zero to trigger division by 0 exception

        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch(const std::invalid_argument& e)
    {
        // Targeted exception handling for specific error types
        std::cout << "Division error caught and handled: " << e.what() << std::endl;
        std::cout << "Division operation safely aborted." << std::endl;
    }}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    // TODO: Create exception handlers that catch (in this order): (COMPLETED)
    // your custom exception, std::exception, uncaught exception 
    // that wraps the whole main function, and displays a message to the console.

    // 3-tier exception handling
    try
    {
        // Execute all test functions in protected try block
        do_division();              // Test division by 0 handling
        do_custom_application_logic(); // Test nested exception handling & custom exceptions
    }
    catch(const CustomApplicationException& e)
    {
        // 1st catch block: Handle specific custom exception
        std::cout << "Caught custom application exception: " << e.what() << std::endl;
        std::cout << "Custom exception handled gracefully." << std::endl;
    }
    catch(const std::exception& e)
    {
        // 2nd catch block: Handle any std library exception not caught above
        std::cout << "Caught standard library exception: " << e.what() << std::endl;
        std::cout << "Standard exception handled safely." << std::endl;
    }
    catch(...)
    {
        // 3rd catch block: Catch-all handler for any other non-standard exceptions
        // Last resort for exceptions not derived from std::exception
        std::cout << "Caught unknown exception type (not derived from std::exception)" << std::endl;
        std::cout << "Unknown exception handled to prevent program termination." << std::endl;
    }

    std::cout << "Program completed successfully despite exceptions." << std::endl;
    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
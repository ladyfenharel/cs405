CS 405 Unit Test Project — Vector Collection Tests

Environment: macOS, Visual Studio Code, CMake, Google Test

How to Build and Run the Project (macOS)

1. Install Dependencies (if you haven’t already):
   brew install cmake gcc

2. Clone Google Test into project directory:
   git clone https://github.com/google/googletest.git

3. Project Folder Structure Should Look Something Like:
   /test
     ├── test.cpp
     ├── CMakeLists.txt
     └── googletest/

4. Build the Project:
   mkdir build
   cd build
   cmake ..
   make

5. Run the Tests:
   ./runTests

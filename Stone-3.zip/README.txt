README - SQL Injection Detection Program
==========================================

REQUIREMENTS:
- C++ compiler (g++, clang++, or similar)
- SQLite3 development library

INSTALLATION:

For Linux/Ubuntu:
  sudo apt-get install sqlite3 libsqlite3-dev build-essential

For macOS:
  brew install sqlite3
  (Xcode command line tools: xcode-select --install)

For Windows:
  Install MinGW-w64 or use WSL with Linux instructions above

COMPILATION:
  g++ -o SQLInjection SQLInjection.cpp -lsqlite3

RUNNING:
  ./SQLInjection
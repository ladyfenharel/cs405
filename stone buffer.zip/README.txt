Buffer Overflow Fix Project - README

This project was developed using Visual Studio Code (VS Code) on macOS.
It does not include a .sln solution file because VS Code does not generate those.
However, the project can be easily compiled and run using any C++ compiler.

How to Compile and Run (macOS / Linux)

1. Open a terminal.
2. Navigate to the folder containing the file:
   cd /path/to/project

3. Compile the C++ source file:
   g++ BufferOverflow.cpp -o BufferOverflow

4. Run the program:
   ./BufferOverflow

Input Behavior

- The program will prompt: "Enter a value (max 19 characters):"
- If you enter a string longer than 19 characters, it will:
  - Notify you: "Input too long! Maximum allowed is 19 characters."
  - Prevent any unsafe behavior or memory overwrite.


- The core logic is self-contained in a single file and does not require external libraries.
